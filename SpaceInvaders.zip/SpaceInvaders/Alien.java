public class Alien extends gameChar{
    
    boolean isVis;
    
    public Alien(int x, int y){
        super(x,y);
        isVis = true;
        
    }
}