public class Shot extends gameChar{
    public Shot(double x, double y){
        super(x,y);
    }
}